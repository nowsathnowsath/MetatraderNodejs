// grab the packages we need
var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);
var port = 3020;
var bodyParser = require('body-parser');
app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies

//var app = require('express')();


app.get('/', function(req, res){
    res.sendFile(__dirname + '/index.html');
});
app.post('/SendTickData', function(req, res) {
    
    var signaldata_string= JSON.stringify(req.body);
    var signaldata_json = JSON.parse(signaldata_string);
    io.emit('tickdata',signaldata_json); 
    //console.log(signaldata_json);
    res.end("ok");
});

io.on('connection', function(socket){
    console.log('a user connected');
  });

http.listen(port, function(){
  console.log('listening on *:'+port);
});